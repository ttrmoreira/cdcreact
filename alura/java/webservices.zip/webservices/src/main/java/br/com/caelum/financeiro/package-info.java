@javax.xml.bind.annotation.XmlSchema (
      namespace="http://financeiro.com.br/nota",
      elementFormDefault=javax.xml.bind.annotation.XmlNsForm.QUALIFIED
)
package br.com.caelum.financeiro;

